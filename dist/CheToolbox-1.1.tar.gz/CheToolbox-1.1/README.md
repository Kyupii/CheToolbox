# CheToolbox
Co-Written by Quan Phan & Ethan Molnar
## About
CheToolbox or Chemical Engineer's Toolbox is a personal project designed to package the calculations I have learned from university for easy access and time saving.
## License
CheToolbox is distributed under GPL Liscense version 3 (GPLv3)
## Dependencies
The following dependencies will be necessary for CheToolbox to build properly,
- Python >= 2.7, < 3.0: http://www.python.org/ (Also install development files.)
- PIP >= 7.0: https://pip.pypa.io/ (Not required in some scenarios but never bad to have.)
- SciPy >= 0.11.0: http://www.scipy.org/
- NumPy >= 1.16.0: http://www.numpy.org/
## Usage
